package com.example.realistictrees.client;

import com.example.realistictrees.FallingTreeEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;
import org.joml.Vector3f;

public class FallingTreeRenderer extends EntityRenderer<FallingTreeEntity> {
    public FallingTreeRenderer(EntityRendererFactory.Context ctx) { super(ctx); }

    @Override
    public void render(FallingTreeEntity e, float yaw, float tickDelta, MatrixStack m, VertexConsumerProvider vc, int light) {
        int[] d = e.getBlockData();
        if (d.length == 0) return;
        Direction dir = e.getFallDir();
        int dx = dir.getOffsetX(), dz = dir.getOffsetZ();

        float t = Math.min((e.age + tickDelta) / FallingTreeEntity.DURATION, 1f);
        // slow start (creaking), then accelerates like a real tree, tiny rebound at the end
        float ang = t * t * t * 90f;
        if (t > 0.92f) ang -= (float) Math.sin((t - 0.92f) / 0.08f * Math.PI) * 1.5f;

        m.push();
        m.multiply(RotationAxis.of(new Vector3f(dz, 0, -dx)).rotationDegrees(ang));
        var brm = MinecraftClient.getInstance().getBlockRenderManager();
        for (int i = 0; i + 3 < d.length; i += 4) {
            BlockState s = Block.getStateFromRawId(d[i + 3]);
            m.push();
            m.translate(d[i] - 0.5 - 0.5 * dx, d[i + 1], d[i + 2] - 0.5 - 0.5 * dz);
            brm.renderBlockAsEntity(s, m, vc, light, OverlayTexture.DEFAULT_UV);
            m.pop();
        }
        m.pop();
    }

    @Override
    public Identifier getTexture(FallingTreeEntity e) { return SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE; }
}
