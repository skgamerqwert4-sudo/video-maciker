package com.example.realistictrees.client;

import com.example.realistictrees.RealisticTrees;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class RealisticTreesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(RealisticTrees.FALLING_TREE, FallingTreeRenderer::new);
    }
}
