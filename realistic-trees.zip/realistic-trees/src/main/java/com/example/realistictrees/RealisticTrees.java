package com.example.realistictrees;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.*;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.*;

public class RealisticTrees implements ModInitializer {
    public static final String MOD_ID = "realistictrees";
    public static final int MAX_LOGS = 300;
    public static final int MAX_BLOCKS = 800;
    public static final int MAX_LEAF_DIST = 6;

    public static final EntityType<FallingTreeEntity> FALLING_TREE = Registry.register(
        Registries.ENTITY_TYPE,
        new Identifier(MOD_ID, "falling_tree"),
        FabricEntityTypeBuilder.<FallingTreeEntity>create(SpawnGroup.MISC, FallingTreeEntity::new)
            .dimensions(EntityDimensions.fixed(0.2f, 0.2f))
            .trackRangeBlocks(160)
            .trackedUpdateRate(10)
            .forceTrackedVelocityUpdates(false)
            .build());

    @Override
    public void onInitialize() {
        PlayerBlockBreakEvents.AFTER.register(RealisticTrees::onBreak);
    }

    private static void onBreak(World world, PlayerEntity player, BlockPos pos, BlockState state, BlockEntity be) {
        if (!(world instanceof ServerWorld sw)) return;
        if (player.isSneaking()) return; // sneak = break normally
        if (!state.isIn(BlockTags.LOGS)) return;
        if (!world.getBlockState(pos.down()).isIn(BlockTags.DIRT)) return; // only the bottom log

        // 1) find connected logs
        Set<BlockPos> seen = new HashSet<>();
        Set<BlockPos> logs = new LinkedHashSet<>();
        Deque<BlockPos> q = new ArrayDeque<>();
        q.add(pos); seen.add(pos);
        while (!q.isEmpty() && logs.size() < MAX_LOGS) {
            BlockPos c = q.poll();
            for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dy == 0 && dz == 0) continue;
                BlockPos n = c.add(dx, dy, dz);
                if (n.getY() < pos.getY()) continue;
                if (Math.abs(n.getX() - pos.getX()) > 12 || Math.abs(n.getZ() - pos.getZ()) > 12) continue;
                if (!seen.add(n)) continue;
                if (world.getBlockState(n).isIn(BlockTags.LOGS)) { logs.add(n.toImmutable()); q.add(n.toImmutable()); }
            }
        }
        if (logs.size() < 2) return;

        // 2) find natural leaves attached to those logs
        Map<BlockPos, Integer> dist = new HashMap<>();
        Deque<BlockPos> lq = new ArrayDeque<>();
        for (BlockPos l : logs) { dist.put(l, 0); lq.add(l); }
        Set<BlockPos> leaves = new LinkedHashSet<>();
        while (!lq.isEmpty() && logs.size() + leaves.size() < MAX_BLOCKS) {
            BlockPos c = lq.poll();
            int d = dist.get(c);
            if (d >= MAX_LEAF_DIST) continue;
            for (Direction dir : Direction.values()) {
                BlockPos n = c.offset(dir);
                if (dist.containsKey(n)) continue;
                BlockState ns = world.getBlockState(n);
                if (ns.isIn(BlockTags.LEAVES) && !(ns.contains(LeavesBlock.PERSISTENT) && ns.get(LeavesBlock.PERSISTENT))) {
                    dist.put(n.toImmutable(), d + 1);
                    leaves.add(n.toImmutable());
                    lq.add(n.toImmutable());
                }
            }
        }
        if (leaves.isEmpty()) return; // not a real tree (e.g. a log cabin)

        // 3) pack blocks and remove them from the world
        Direction fall = player.getHorizontalFacing();
        List<Integer> data = new ArrayList<>();
        List<BlockPos> all = new ArrayList<>(logs);
        all.addAll(leaves);
        for (BlockPos p : all) {
            BlockState s = world.getBlockState(p);
            data.add(p.getX() - pos.getX());
            data.add(p.getY() - pos.getY());
            data.add(p.getZ() - pos.getZ());
            data.add(Block.getRawIdFromState(s));
        }
        for (BlockPos p : all) world.removeBlock(p, false);

        FallingTreeEntity e = new FallingTreeEntity(FALLING_TREE, world);
        e.setPosition(pos.getX() + 0.5 + 0.5 * fall.getOffsetX(), pos.getY(), pos.getZ() + 0.5 + 0.5 * fall.getOffsetZ());
        e.setTree(data.stream().mapToInt(Integer::intValue).toArray(), fall.getHorizontal());
        world.spawnEntity(e);
    }
}
