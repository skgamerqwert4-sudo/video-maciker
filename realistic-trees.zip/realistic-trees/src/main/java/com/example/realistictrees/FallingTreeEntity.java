package com.example.realistictrees;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

public class FallingTreeEntity extends Entity {
    public static final int DURATION = 45; // ticks (~2.2 sec)
    private static final TrackedData<NbtCompound> TREE = DataTracker.registerData(FallingTreeEntity.class, TrackedDataHandlerRegistry.NBT_COMPOUND);
    private static final TrackedData<Integer> DIR = DataTracker.registerData(FallingTreeEntity.class, TrackedDataHandlerRegistry.INTEGER);

    public FallingTreeEntity(EntityType<?> type, World world) {
        super(type, world);
        this.noClip = true;
        this.setNoGravity(true);
    }

    @Override
    protected void initDataTracker() {
        dataTracker.startTracking(TREE, new NbtCompound());
        dataTracker.startTracking(DIR, 0);
    }

    public void setTree(int[] data, int dir) {
        NbtCompound c = new NbtCompound();
        c.putIntArray("d", data);
        dataTracker.set(TREE, c);
        dataTracker.set(DIR, dir);
    }

    public int[] getBlockData() { return dataTracker.get(TREE).getIntArray("d"); }
    public Direction getFallDir() { return Direction.fromHorizontal(dataTracker.get(DIR)); }

    @Override
    public void tick() {
        super.tick();
        age++;
        if (age == 1 && !getWorld().isClient) {
            getWorld().playSound(null, getBlockPos(), SoundEvents.BLOCK_WOOD_BREAK, SoundCategory.BLOCKS, 2f, 0.6f);
        }
        if (!getWorld().isClient) {
            if (getBlockData().length == 0) { discard(); return; }
            if (age >= DURATION) land();
        }
    }

    private void land() {
        World w = getWorld();
        Direction d = getFallDir();
        int dx = d.getOffsetX(), dz = d.getOffsetZ();
        int bx = (int) Math.floor(getX() - 0.5 * dx);
        int bz = (int) Math.floor(getZ() - 0.5 * dz);
        int by = (int) Math.floor(getY());
        int[] data = getBlockData();
        for (int i = 0; i + 3 < data.length; i += 4) {
            int ox = data[i], oy = data[i + 1], oz = data[i + 2];
            BlockState s = Block.getStateFromRawId(data[i + 3]);
            int a = ox * dx + oz * dz;      // distance along fall direction
            int l = -ox * dz + oz * dx;     // sideways offset
            int na = oy + 1;                // after 90 deg rotation
            int ny = -a;
            BlockPos t = new BlockPos(bx + na * dx - l * dz, by + ny, bz + na * dz + l * dx);
            if (s.contains(Properties.AXIS) && !s.contains(Properties.FACING)) {
                s = s.with(Properties.AXIS, d.getAxis());
            }
            BlockState cur = w.getBlockState(t);
            if (cur.isAir() || cur.isReplaceable()) {
                w.setBlockState(t, s, Block.NOTIFY_ALL);
            } else {
                Block.dropStacks(s, w, new BlockPos(bx, by, bz));
            }
        }
        w.playSound(null, getBlockPos(), SoundEvents.BLOCK_WOOD_FALL, SoundCategory.BLOCKS, 3f, 0.5f);
        w.playSound(null, getBlockPos(), SoundEvents.BLOCK_GRASS_BREAK, SoundCategory.BLOCKS, 3f, 0.6f);
        discard();
    }

    @Override protected void readCustomDataFromNbt(NbtCompound nbt) {
        if (nbt.contains("Tree")) dataTracker.set(TREE, nbt.getCompound("Tree"));
        dataTracker.set(DIR, nbt.getInt("Dir"));
        age = nbt.getInt("Age");
    }
    @Override protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.put("Tree", dataTracker.get(TREE));
        nbt.putInt("Dir", dataTracker.get(DIR));
        nbt.putInt("Age", age);
    }
    @Override public Packet<ClientPlayPacketListener> createSpawnPacket() { return new EntitySpawnS2CPacket(this); }
    @Override public boolean isAttackable() { return false; }
    @Override public boolean canHit() { return false; }
}
