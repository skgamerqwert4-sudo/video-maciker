Realistic Trees (Fabric 1.20.1)
Build:  JDK 17 chahiye.  ./gradlew build   (gradle wrapper nahi hai to: gradle wrapper --gradle-version 8.5)
Jar:    build/libs/realistic-trees-1.0.0.jar  -> mods folder me daalo (Fabric Loader + Fabric API ke saath)
Use:    Pedh ka sabse neeche wala log (jo mitti par hai) todo -> poora ped gir jayega. Sneak karke todo = normal break.
Textures: src/main/resources/assets/minecraft/textures/block  (gen_textures.py se banaye; apni PNG se replace kar sakte ho)
