from PIL import Image
import random, math, os
S = 32
OUT = "src/main/resources/assets/minecraft/textures/block"
def clamp(v): return max(0, min(255, int(v)))

def bark(name, base, seed, birch=False):
    r = random.Random(seed)
    cols = [r.random() for _ in range(S)]
    ridge = [(cols[i-1] + cols[i] + cols[(i+1) % S]) / 3 for i in range(S)]
    vn = [[r.random() for _ in range(S//4 + 2)] for _ in range(S)]
    img = Image.new("RGBA", (S, S))
    for x in range(S):
        for y in range(S):
            v = vn[x][y//4] * (1 - (y % 4)/4) + vn[x][y//4 + 1] * ((y % 4)/4)
            shade = 0.75 + 0.9*(ridge[x]-0.5) + 0.35*(v-0.5) + r.uniform(-0.05, 0.05)
            if not birch and ridge[x] < 0.42 and v > 0.3: shade -= 0.30
            c = [clamp(b*shade) for b in base]
            img.putpixel((x, y), (*c, 255))
    if birch:
        for _ in range(26):
            x, y, w = r.randrange(S), r.randrange(S), r.randint(2, 6)
            for i in range(w):
                img.putpixel(((x+i) % S, y), (35, 35, 35, 255))
    img.save(f"{OUT}/{name}.png")

def top(name, inner, outer, seed):
    r = random.Random(seed)
    img = Image.new("RGBA", (S, S))
    ph = r.random()*6
    for x in range(S):
        for y in range(S):
            dx, dy = x-S/2+0.5, y-S/2+0.5
            d = math.hypot(dx, dy) + 0.6*math.sin(math.atan2(dy, dx)*3+ph)
            edge = max(abs(dx), abs(dy))
            if edge > S/2-3:
                s = 0.8 + r.uniform(-0.15, 0.15); base = outer
            else:
                ring = 0.5 + 0.5*math.sin(d*1.5)
                s = 0.82 + 0.28*ring + r.uniform(-0.04, 0.04); base = inner
            img.putpixel((x, y), (*[clamp(b*s) for b in base], 255))
    img.save(f"{OUT}/{name}.png")

def leaves(name, seed):
    r = random.Random(seed)
    img = Image.new("RGBA", (S, S))
    blob = [[r.random() for _ in range(S//2)] for _ in range(S//2)]
    for x in range(S):
        for y in range(S):
            b = blob[x//2][y//2]
            hole = b < 0.14 and r.random() < 0.9
            g = clamp(95 + 110*b + r.uniform(-18, 18))
            if (x+y) % 7 == 0: g = clamp(g*0.8)
            img.putpixel((x, y), (g, g, g, 0 if hole else 255))
    img.save(f"{OUT}/{name}.png")

woods = {
 "oak": ((120, 92, 58), (190, 150, 95), 1),
 "spruce": ((82, 60, 40), (125, 95, 58), 2),
 "birch": ((225, 225, 215), (215, 195, 140), 3),
 "jungle": ((110, 85, 50), (175, 135, 85), 4),
 "acacia": ((125, 118, 108), (175, 100, 60), 5),
 "dark_oak": ((62, 46, 28), (95, 70, 40), 6),
}
for n, (b, inner, s) in woods.items():
    bark(f"{n}_log", b, s*11, birch=(n == "birch"))
    top(f"{n}_log_top", inner, b, s*17)
    leaves(f"{n}_leaves", s*23)
print(sorted(os.listdir(OUT)))
